
#ifndef OTBOSSIMAdapters_EXPORT_H
#define OTBOSSIMAdapters_EXPORT_H

#ifdef OTB_STATIC
#  define OTBOSSIMAdapters_EXPORT
#  define OTBOSSIMAdapters_HIDDEN
#  define OTBOSSIMAdapters_EXPORT_TEMPLATE
#  define OTBOSSIMAdapters_EXPORT_EXPLICIT_TEMPLATE
#else
#  ifndef OTBOSSIMAdapters_EXPORT
#    ifdef OTBOSSIMAdapters_EXPORTS
        /* We are building this library */
#      define OTBOSSIMAdapters_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBOSSIMAdapters_EXPORT __attribute__((visibility("default")))
#    endif
#  endif
#  ifndef OTBOSSIMAdapters_EXPORT_TEMPLATE
        /* We are building this library */
#      define OTBOSSIMAdapters_EXPORT_TEMPLATE __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define OTBOSSIMAdapters_EXPORT_TEMPLATE __attribute__((visibility("default")))
#  endif
#  ifndef OTBOSSIMAdapters_EXPORT_EXPLICIT_TEMPLATE
        /* We are building this library */
#      define OTBOSSIMAdapters_EXPORT_EXPLICIT_TEMPLATE 
#    else
        /* We are using this library */
#      define OTBOSSIMAdapters_EXPORT_EXPLICIT_TEMPLATE 
#  endif
#  ifndef OTBOSSIMAdapters_HIDDEN
#    define OTBOSSIMAdapters_HIDDEN __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef OTBOSSIMAdapters_DEPRECATED
#  define OTBOSSIMAdapters_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef OTBOSSIMAdapters_DEPRECATED_EXPORT
#  define OTBOSSIMAdapters_DEPRECATED_EXPORT OTBOSSIMAdapters_EXPORT OTBOSSIMAdapters_DEPRECATED
#endif

#ifndef OTBOSSIMAdapters_DEPRECATED_NO_EXPORT
#  define OTBOSSIMAdapters_DEPRECATED_NO_EXPORT OTBOSSIMAdapters_HIDDEN OTBOSSIMAdapters_DEPRECATED
#endif

#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef OTBOSSIMADAPTERS_NO_DEPRECATED
#    define OTBOSSIMADAPTERS_NO_DEPRECATED
#  endif
#endif

#endif /* OTBOSSIMAdapters_EXPORT_H */
